# P1530
Problem 15.30
